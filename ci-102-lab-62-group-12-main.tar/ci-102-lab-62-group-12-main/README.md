# CI 102 Lab 62 Group 12



## Getting started

To make it easy for you to get started with GitLab, here's a list of recommended next steps.

Already a pro? Just edit this README.md and make it your own. Want to make it easy? [Use the template at the bottom](#editing-this-readme)!

## Add your files

- [ ] [Create](https://docs.gitlab.com/ee/user/project/repository/web_editor.html#create-a-file) or [upload](https://docs.gitlab.com/ee/user/project/repository/web_editor.html#upload-a-file) files
- [ ] [Add files using the command line](https://docs.gitlab.com/ee/gitlab-basics/add-file.html#add-a-file-using-the-command-line) or push an existing Git repository with the following command:

```
cd existing_repo
git remote add origin https://gitlab.cci.drexel.edu/fds24/ci10x-student-teams/62/12/ci-102-lab-62-group-12.git
git branch -M main
git push -uf origin main
```

## Integrate with your tools

- [ ] [Set up project integrations](https://gitlab.cci.drexel.edu/fds24/ci10x-student-teams/62/12/ci-102-lab-62-group-12/-/settings/integrations)

## Collaborate with your team

- [ ] [Invite team members and collaborators](https://docs.gitlab.com/ee/user/project/members/)
- [ ] [Create a new merge request](https://docs.gitlab.com/ee/user/project/merge_requests/creating_merge_requests.html)
- [ ] [Automatically close issues from merge requests](https://docs.gitlab.com/ee/user/project/issues/managing_issues.html#closing-issues-automatically)
- [ ] [Enable merge request approvals](https://docs.gitlab.com/ee/user/project/merge_requests/approvals/)
- [ ] [Set auto-merge](https://docs.gitlab.com/ee/user/project/merge_requests/merge_when_pipeline_succeeds.html)

## Test and Deploy

Use the built-in continuous integration in GitLab.

- [ ] [Get started with GitLab CI/CD](https://docs.gitlab.com/ee/ci/quick_start/index.html)
- [ ] [Analyze your code for known vulnerabilities with Static Application Security Testing (SAST)](https://docs.gitlab.com/ee/user/application_security/sast/)
- [ ] [Deploy to Kubernetes, Amazon EC2, or Amazon ECS using Auto Deploy](https://docs.gitlab.com/ee/topics/autodevops/requirements.html)
- [ ] [Use pull-based deployments for improved Kubernetes management](https://docs.gitlab.com/ee/user/clusters/agent/)
- [ ] [Set up protected environments](https://docs.gitlab.com/ee/ci/environments/protected_environments.html)

***

## Medy
Your Friend in Health

## Description
Welcome to Medy, your ultimate fitness companion! Medy is a comprehensive fitness website that helps you stay on top of your health goals by tracking your protein and caloric intake and providing a map of nearby gyms
Features:
Nutrition Tracking Protein Intake: Log your daily protein consumption to ensure you are meeting your dietary goals. Caloric Intake: Keep track of your daily calorie intake to manage your weight effectively. 
Nutritional Insights: Get detailed insights and recommendations based on your dietary habits. Gym Locator Nearby Gyms: Use our interactive map to find gyms near your location. 
Gym Details: Access information about each gym, including address, contact details, and available facilities. Directions: Get step-by-step directions to the gym of your choice.

## Installation
Medy is a web-based application, however, there is no hosting available currently for our website. Therefore, you should download our code, go into the mainMedi branch, head over to the homepage folder, click on the HTML file and click liveserver to see our website. You must have liveserver installed onto your device to view our website.

## Usage
Tracking Nutrition
Log Protein Intake:

Go to the Nutrition section.
Enter the amount of protein consumed in grams.
Click Submit to save your entry.
Log Caloric Intake:

Go to the Nutrition section.
Enter the number of calories consumed.
Click Submit to save your entry.
View Insights:

Navigate to the Insights tab.
Review your daily, weekly, and monthly intake summaries.
Follow the recommendations provided to optimize your diet.
Finding Gyms
Locate Nearby Gyms:

Go to the Gym Locator section.
Allow location access if prompted.
View the map with highlighted gyms near you.
Gym Details:

Click on a gym marker on the map.
View the gym’s address, contact information, and facilities offered.
Get Directions:

Click on the Get Directions button.
Follow the provided route to reach the gym.

## Support
If you have any questions or need assistance, please contact our support team:

Email: jss438@drexel.edu sns348@drexel.edu mtr96@drexel.edu jj3275@drexel.edu

## Contributing
We welcome contributions from the community! If you'd like to contribute to Medy, please follow these steps:

Fork the repository.
Create a new branch (git checkout -b feature/YourFeature).
Make your changes.
Commit your changes (git commit -m 'Add your feature').
Push to the branch (git push origin feature/YourFeature).
Open a Pull Request.

## License
Medy is licensed under the MIT License.

## Acknowledgments
We would like to thank all the users and contributors who have helped make Medy the best fitness companion on the web.

Stay healthy and fit with Medy - Your Friend in Health!